#!/bin/bash
# Run this as root.
set -e
iptables-restore < rules.v4
ip6tables-restore < rules.v6

if hash apt-get; then
	apt-get update
	apt-get upgrade
elif hash yum; then
	yum update
else
	echo "No apt-get and no yum. Have fun! Exiting..."
	exit 1
fi

echo "Users wish shells include: "
cat /etc/password | grep sh
